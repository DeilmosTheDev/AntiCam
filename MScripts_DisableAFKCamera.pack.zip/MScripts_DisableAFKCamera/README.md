-- ##########################################################################
-- please make sure to hit the subscribe button to my youtube MononokeStudios
-- please make sure you go visit www.Mononoke-Studios.dev
-- please make sure to take a look at my other scripts on https://www.m-scripts.store
-- join our discord server https://discord.gg/Kd8h2YmvHV
-- ##########################################################################
-- thanks for using my scripts best regards and god bless you
-- by Deilmos
-- Mononoke-Studios
-- ##########################################################################



## Features

- Roleplayservers never will have the AFK cam anymore
- Roleplayserver streamers dont have to move the character to dont get the AFK cam in a szene
- Easy to put more elementes inside and it is totally free

## Installation

1. Copy the resource folder into your server resources directory:

2. Ensure the resource in your `server.cfg`:

3. Open `config.lua` and configure the toggles to your needs.

4. Restart the server (or start the resource). // You could use TX Admin to easy test

That’s it.

---

## Configuration

You can simple change wait(1000) how you like it. The frames you dont want the script to call your server for refresh it. The afk cam normally comes after 30 seconds so you can go for more than wait(0) easily


Compatibility

ESX ✔

QBCore ✔

Standalone ✔

No server-side dependencies

No database required

License / Usage

You may:

Use this resource on your server

Modify it for your needs

You may not:

Re-upload as-is without permission

Claim original authorship while its made by me deilmos


-- ##########################################################################
-- please make sure to hit the subscribe button to my youtube MononokeStudios
-- please make sure you go visit www.Mononoke-Studios.dev
-- please make sure to take a look at my other scripts on www.m-scripts.store
-- join our discord server https://discord.gg/Kd8h2YmvHV
-- ##########################################################################
-- thanks for using my scripts best regards and god bless you
-- by Deilmos
-- Mononoke-Studios
-- ##########################################################################